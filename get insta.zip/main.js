function inputget() {
  let inputname = document.getElementById('inputname').value;
  document.getElementById('name').innerHTML = inputname;
  //document call
  let name = inputname.toLowerCase();
  let image = document.getElementById('image_me');
  let insta = document.getElementById('insta');
  // switch the name
  switch (name) {
    case 'subodh' : 
      image.src ='asset/imageme/subodh.jpg';
    insta.href = 'https://instagram.com/subodh.06';
    break;
    
    case 'subhranshu':
      image.src = 'asset/imageme/subhranshu.jpg';
      insta.href = 'https://instagram.com/panda.subhranshu';
      break;
      
      case 'nipran':
        image.src = 'asset/imageme/nipran.jpg';
        insta.href = 'https://instagram.com/nipran.06';
        
        break;
      case 'jagadananda':
        image.src = '/asset/imageme/jagadananda.jpg';
        
        insta.href = 'https://instagram.com/jagadanandamohapatra';
        break;
        case 'william':
    image.src = 'asset/imageme/William.jpg';
     insta.href = 'https://instagram.com/zeal_10k';
        break;
        
        case 'swayam':
          image.src ='asset/imageme/swayam.jpg';
          insta.href = 'https://instagram.com/01_smart_king';
          break;
          
       case 'abhijit':
      image.src = 'asset/imageme/abhijit.jpg';
         insta.href = 'https://instagram.com/darksunabhijit';
         
         break;
          
        
      
    default : 
    image.src = '/asset/image/20221201_192015.jpg'
    
      
  }
  
}
